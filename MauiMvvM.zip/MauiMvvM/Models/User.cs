﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MauiMvvM.Models
{
    public class User
    {
        public string ?Name { get; set; }
        public string ?Password { get; set; }
    }
}
