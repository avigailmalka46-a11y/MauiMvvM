using MauiMvvM.Servies;
using MauiMvvM.ViewModels;

namespace MauiMvvM.Views;

public partial class LoginPageView : ContentPage
{
    public LoginPageView()
    {
        InitializeComponent();

        BindingContext = new LoginPageViewModel();
    }
}